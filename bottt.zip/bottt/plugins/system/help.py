import __main__
from telethon import events

# استخدام الكلاينت المعرف في الملف الرئيسي
client = __main__.client

@client.on(events.NewMessage(pattern=r"^\.الاوامر$"))
async def help_command(event):
    # قائمة الأوامر اللي طلبتها
    help_text = (
        "★────────☭────────★\n"
        "  ☭ • 𝑆𝑂𝑈𝑅𝐶𝐸 𝑁𝐸𝑇𝐻𝑅𝑂𝑁 • ☭\n\n"
        "• .م1  •【اوامر الحساب】\n\n"
        "• .م2 • 【اوامر 】\n\n"
        "• .م3 • 【اوامر النشر التلقائي】\n\n"
        "• .م4 • 【اوامر الخاص】\n\n"
        "★────────☭────────★"
    )

    try:
        # تعديل الرسالة اللي أرسلتها (بدون حذف)
        await event.edit(help_text)
        print("✅ تم عرض قائمة الأوامر بتعديل الرسالة")
        
    except Exception as e:
        # في حال حدوث خطأ أو إذا كان الحساب يحاول الرد على شخص آخر
        await event.reply(help_text)
        print(f"❌ حدث خطأ أثناء التعديل: {e}")