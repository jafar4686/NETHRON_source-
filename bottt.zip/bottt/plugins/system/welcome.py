import __main__
from telethon import events
from datetime import datetime
import os

# استخدام الكلاينت من الملف الرئيسي لتجنب التداخل
client = __main__.client

@client.on(events.NewMessage(pattern=r"^/s$"))
async def welcome_command(event):
    try:
        sender = await event.get_sender()
        name = sender.first_name or "المستخدم"
        username = f"@{sender.username}" if sender.username else "لا يوجد"
        date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        version = "1.0.0"

        # تحضير النص المطلوب
        welcome_text = (
            "★────────☭────────★\n"
            "   ☭ • 𝑆𝑂𝑈𝑅𝐶𝐸 𝑁𝐸𝑇𝐻𝑅𝑂𝑁 • ☭\n"
            "                  ☭ • سورس نيثرون • ☭\n\n"
            f"☭ • الاسم: {name}\n"
            f"☭ • الوصف: سورس نيثرون يعمل بنجاح\n"
            f"☭ • اليوزر: {username}\n"
            f"☭ • تاريخ: {date}\n"
            f"☭ • تحديث السورس: {version}\n\n"
            "ملاحظة: لعرض الاوامر اكتب (.اوامر)"
        )

        # مسار الصورة في مجلد assets
        photo_path = "assets/welcome.jpg"

        # التأكد من وجود ملف الصورة فعلياً
        if os.path.exists(photo_path):
            # إرسال الصورة مع النص كـ وصف (Caption)
            await client.send_file(
                event.chat_id,
                photo_path,
                caption=welcome_text
            )
        else:
            # إذا لم توجد الصورة يرسل النص فقط لكي لا يتوقف البوت
            await event.reply(welcome_text)
            print("⚠️ تنبيه: ملف الصورة غير موجود، تم إرسال نص فقط.")

    except Exception as e:
        print(f"❌ حدث خطأ: {e}")