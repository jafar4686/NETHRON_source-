import __main__
from telethon import events
import time

# الوصول للكلاينت المعرف في الملف الرئيسي
client = __main__.client

# 1. قائمة الأوامر م1 المنسقة والجديدة
@client.on(events.NewMessage(pattern=r"^\.م1$"))
async def m1_command(event):
    m1_text = (
        "★────────☭────────★\n"
        "   ☭ • 𝑆𝑂𝑈𝑅𝐶𝐸 𝑁𝐸𝑇𝐻𝑅𝑂𝑁 • ☭\n"
        "                  ☭ • سورس نيثرون • ☭\n"
        "★────────☭────────★\n\n"
        "⚙️ **أوامر الحساب والتحكم:**\n\n"
        "• `.وقتي` (اسم | بايو)\n"
        "➥ يضع وقتك الحالي بصف اسمك/بايوك\n\n"
        "• `.ايقاف وقتي` \n"
        "➥ إيقاف الوقت وتنظيف الحساب فوراً\n\n"
        "• `.تغيير تلقائي` (اسم | بايو)\n"
        "➥ تبديل الأسماء/البايو بشكل دوري\n\n"
        "• `.ذاتيه` (تفعيل | تعطيل)\n"
        "➥ حفظ الرسائل المحذوفة للمحفوظات\n\n"
        "• `.حمايه` (تفعيل | تعطيل)\n"
        "➥ تفعيل نظام الردع للمزعجين\n\n"
        "• `.نسخ` (بالرد) | `.ارجاع` \n"
        "➥ انتحال حساب الشخص أو العودة لوضعك\n\n"
        "★────────☭────────★\n"
        "💬 **ملاحظة:** لعرض الأوامر العامة أرسل `.الاوامر`"
    )
    try:
        await event.edit(m1_text)
    except Exception as e:
        print(f"Error editing message: {e}")

# 2. أمر فحص السرعة (بينج)
@client.on(events.NewMessage(pattern=r"^\.بينج$"))
async def ping(event):
    start = time.time()
    await event.edit("🚀")
    end = time.time()
    ms = round((end - start) * 1000)
    await event.edit(f"• استجابة السورس: `{ms}ms`")

# 3. أمر معلومات الحساب (ايدي)
@client.on(events.NewMessage(pattern=r"^\.ايدي$"))
async def get_id(event):
    me = await client.get_me()
    info = (
        "★────────☭────────★\n"
        f"• الاسم: {me.first_name}\n"
        f"• الايدي: `{me.id}`\n"
        f"• اليوزر: @{me.username if me.username else 'لا يوجد'}\n"
        "★────────☭────────★"
    )
    await event.edit(info)