# plugins/__init__.py
print("Plugins folder loaded")
